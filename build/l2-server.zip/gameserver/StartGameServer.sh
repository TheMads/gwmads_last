#!/bin/bash

./GameServer_loop.sh &



